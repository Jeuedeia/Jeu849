// Conteúdo simulado de MainForm.cs

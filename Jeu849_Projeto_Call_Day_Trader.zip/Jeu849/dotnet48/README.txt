// Conteúdo simulado de README.txt
